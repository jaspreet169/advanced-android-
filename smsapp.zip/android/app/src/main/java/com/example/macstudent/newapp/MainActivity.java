package com.example.macstudent.newapp;

import android.Manifest;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.telephony.SmsManager;
import android.widget.TextView;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

public class MainActivity extends AppCompatActivity {

    public final String TAG = "JASPREET";
     PermissionListener smsPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createPermissionListener();
    }


        // set up permission listener
        public void createPermissionListener(){
          if(smsPermission == null ){
              smsPermission = new PermissionListener() {
                  @Override
                  public void onPermissionGranted(PermissionGrantedResponse response) {
                      //PERSON  ALLOW
                      // send the sms
                      SmsManager smsManager = SmsManager.getDefault();
                      smsManager.sendTextMessage("4165695956",null, "TESTING APP ", null, null);

                      // show a message to the user that the message
                      TextView t = (TextView) findViewById(R.id.statusMessage);
                      t.setText("Message sent!");


                  }

                  @Override
                  public void onPermissionDenied(PermissionDeniedResponse response) {
                  //     PERSON DENY
                  }

                  @Override
                  public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                   //IF CURRENT  PERMISSION IS ET TO DENY
                      token.continuePermissionRequest();
                  }
              };
          }

    }



    public void sendButton(View view){
        Log.d(TAG, "sending a sms");

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.SEND_SMS)
                .withListener(smsPermission)
                .check();



    }

}
