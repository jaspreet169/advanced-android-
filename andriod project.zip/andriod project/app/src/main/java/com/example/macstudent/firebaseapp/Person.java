package com.example.macstudent.firebaseapp;

/**
 * Created by macstudent on 2018-04-05.
 */

public class Person {
    public  String name;
    public  String age;
public String email;
public Person(String n, String a, String e){

    this.name = n;
    this.age = a;
    this.email =e;
}


}
