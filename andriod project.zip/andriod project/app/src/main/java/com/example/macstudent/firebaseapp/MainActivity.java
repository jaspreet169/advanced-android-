package com.example.macstudent.firebaseapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {


   FirebaseDatabase db;
   DatabaseReference rootNode;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set up database
        db = FirebaseDatabase.getInstance();
        rootNode = db.getReference();

    }
    //button handler
    public void addclick(View abc){

        EditText text = (EditText)findViewById(R.id.editview);
        EditText age = (EditText)findViewById(R.id.age);
        EditText email = (EditText)findViewById(R.id.email);


        String name = text.getText().toString();
        String page = age.getText().toString();
        String pemail = email.getText().toString();

        //ADD SOMEBODY'S NAME
        //rootNode.child("users").setValue(name)
        // text.setText("");


        //Person p = new Person("PAYAL","23");
        //rootNode.push().setValue(p);

        //Person p1 = new Person("NAVJOT","22");
        //rootNode.push().setValue(p1);

        Person p = new Person(name, page, pemail);
        rootNode.push().setValue(p);

        text.setText("");
        age.setText("");
        email.setText("");
    }




}
