package com.example.macstudent.secondapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by macstudent on 2018-04-17.
 */

public class AirplaneMode extends BroadcastReceiver {


    @Override
    public void onReceive(Context context, Intent intent) {
        //1. message you want to subscibe

        if (intent.getAction()== Intent.ACTION_AIRPLANE_MODE_CHANGED){

            Toast.makeText(context, "airplane mode change",Toast.LENGTH_LONG).show();
        }


        //2. what do you want to do when receive message

    }




}
