package com.example.macstudent.examproject;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

public class MainActivity extends AppCompatActivity {
    public final String TAG = "hello";
    private TextView text;
    private final int SPEECH_REQUEST_CODE = 800;
    private PermissionListener sendSMSPermission;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startSpeech();
        permission();



    }

    public void permission() {
        if (sendSMSPermission == null) {
            sendSMSPermission = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {
                    Log.d(TAG, "sending a sms");

                    // send the sms
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("4165695659",null, "hello  i am testing app", null, null);

                    // show a message to the user that the message
                    TextView t = (TextView) findViewById(R.id.sms);
                    text.setText("Message sent!");




                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {

                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                    token.continuePermissionRequest();

                }
            };


        }
    }
       public void sendsms(View view){


           Dexter.withActivity(this)
                   .withPermission(Manifest.permission.SEND_SMS)
                   .withListener(sendSMSPermission )
                   .check();



       }


 private void startSpeech(){
     Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
     intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
     intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "enter number");
     try {
         // show the popup box
         startActivityForResult(intent, SPEECH_REQUEST_CODE);
     }
     catch (ActivityNotFoundException a) {
         // Sometimes you are using a phone that doesn't have speech to text functions
         // If this happens, then show error message.
         String msg = "Your phone doesn't support speech to text.";
         Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
     }
 }


    public void showme(View view){



    }
}
