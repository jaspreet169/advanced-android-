package com.example.macstudent.androidapp;

import android.Manifest;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.security.Permission;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView t;
    Button b;


    PermissionListener PhonePermission;

    private final int SPEECH_REQUEST_CODE = 800;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t = (TextView) findViewById(R.id.text);
        b = (Button) findViewById(R.id.clickme);

        PhonePermission();
        Dexter.withActivity(this)
                .withPermission(Manifest.permission.CALL_PHONE)
                .withListener(PhonePermission)
                .check();

    }

 public void PhonePermission(){
        if(PhonePermission == null){
            PhonePermission = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {

                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {
                 t.setText("app need permission");
                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                  token.continuePermissionRequest();
                }
            };

        }





 }


    public void dialphone(String number){
        //1 get the phone number and parse into something google understands
        String phoneNumber = "tel:" + number;    // tel automatically opens phone dialer..



        //2 make the phone call
        //a. create a phone dial intent
        Intent dialerIntent = new Intent(Intent.ACTION_CALL);

        // b. configure the intent
        dialerIntent.setData(Uri.parse(phoneNumber));

        // c. start the intent
        startActivity(dialerIntent);


    }


    public void buttonpressed(View view){
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "What color is the sky?");
        try {

            // 2 . Google : llisten and wait for person to finish talking
            //3. Google : automatically translates their speech to text
            // show the popup box
            startActivityForResult(intent, SPEECH_REQUEST_CODE);     //c. start the intent
        } catch (ActivityNotFoundException a) {
            // Sometimes you are using a phone that doesn't have speech to text functions
            // If this happens, then show error message.
            String msg = "Your phone doesn't support speech to text.";
            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
        }
        startActivityForResult(intent,SPEECH_REQUEST_CODE );
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SPEECH_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                // logic get the text and do something with it
                // get
                List<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                // show
                String answer = results.get(0); // get first thing out
                dialphone(answer);
            }

        }


    }
}
