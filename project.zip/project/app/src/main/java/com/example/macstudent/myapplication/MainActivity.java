package com.example.macstudent.myapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private final int no = 244;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sendBUttonPressed(View v) {

        Log.d("hello", "hey there");
        //Toast.makeText(this, "hello everyone", Toast.LENGTH_SHORT).show();



        //1.check permission is granted

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){


            Log.d("hello", "hey there");
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, no);

        }
        else{
            Log.d("text", "Permission granted");
            //send sms
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);


        switch (requestCode){

            //deal with allow & deny for sms
            case no:{
                if(grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    Log.d("text", "permission allow");
                    // send sms
                    sendSMS();
                }
                else{
                    Log.d("text", "sorry permission not allow");
                }

            }
            return;
        }




    }

      public void sendSMS(){

        // 1. get the phn number
          String phnno ="4165695956";


          //2. send sms to this no
          SmsManager smsManager = SmsManager.getDefault();
          smsManager.sendTextMessage(phnno, null,"hello this my first app", null, null );


      }


    }





